==Millénaire Server installation==

Millénaire Server only works with a standard server (and not bukkit).

All your users must have Millénaire installed to connect to your server. Make sure they will be willing and able to install it before you do.

Instructions:
- Install Forge from http://minecraftforge.net/forum/index.php/board,3.0.html
- Move the millenaire-jar, millenaire and millenaire-custom folders inside /mods (create the folder if needed)